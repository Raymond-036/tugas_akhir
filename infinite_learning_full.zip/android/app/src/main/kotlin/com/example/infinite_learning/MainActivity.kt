package com.example.infinite_learning

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
