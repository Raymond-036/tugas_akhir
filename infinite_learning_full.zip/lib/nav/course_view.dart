import 'package:flutter/material.dart';
import 'package:infinite_learning/pages/course_page.dart';

class CourseView extends StatefulWidget {
  const CourseView({super.key});

  @override
  State<CourseView> createState() => _CourseViewState();
}

class _CourseViewState extends State<CourseView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
              margin: EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      margin: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "Course List",
                        style: TextStyle(
                            fontSize: 18,
                            height: 1.4,
                            fontWeight: FontWeight.bold),
                      )),
                  SizedBox(height: 10),
                  Container(
                    height: 35,
                    child: TextField(
                        autofocus: false,
                        decoration: InputDecoration(
                            hintText: "Search...",
                            alignLabelWithHint: true,
                            suffixIcon: Icon(Icons.search),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 5, horizontal: 20),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(
                                    color: Colors.black45, width: 2)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(
                                    color: Colors.black45, width: 2)),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(
                                    color: Colors.black45, width: 2)))),
                  )
                ],
              )),
          SizedBox(height: 10),
          Expanded(
              child: ListView(
            padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
            children: [
              GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (BuildContext context) => CoursePage()));
                  },
                  child: Container(
                    padding: EdgeInsets.only(
                        left: 15, right: 15, top: 15, bottom: 15),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              'assets/images/laptop.png',
                              fit: BoxFit.cover,
                              width: MediaQuery.of(context).size.width,
                            )),
                        SizedBox(height: 10),
                        Text("Web Development",
                            style: TextStyle(
                                fontSize: 16,
                                height: 1.4,
                                fontWeight: FontWeight.bold)),
                        SizedBox(height: 5),
                        Text(
                            "Web development atau pengembangan web, adalah sebuah proses pembangunan dan pemeliharaan situs web",
                            style: TextStyle(
                                fontSize: 12,
                                height: 1.4,
                                fontWeight: FontWeight.normal)),
                      ],
                    ),
                  )),
              SizedBox(height: 20),
              Container(
                padding:
                    EdgeInsets.only(left: 15, right: 15, top: 15, bottom: 15),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset(
                          'assets/images/laptop.png',
                          fit: BoxFit.cover,
                          width: MediaQuery.of(context).size.width,
                        )),
                    SizedBox(height: 10),
                    Text("Web Development",
                        style: TextStyle(
                            fontSize: 16,
                            height: 1.4,
                            fontWeight: FontWeight.bold)),
                    SizedBox(height: 5),
                    Text(
                        "Web development atau pengembangan web, adalah sebuah proses pembangunan dan pemeliharaan situs web",
                        style: TextStyle(
                            fontSize: 12,
                            height: 1.4,
                            fontWeight: FontWeight.normal)),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                padding:
                    EdgeInsets.only(left: 15, right: 15, top: 15, bottom: 15),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset(
                          'assets/images/laptop.png',
                          fit: BoxFit.cover,
                          width: MediaQuery.of(context).size.width,
                        )),
                    SizedBox(height: 10),
                    Text("Web Development",
                        style: TextStyle(
                            fontSize: 16,
                            height: 1.4,
                            fontWeight: FontWeight.bold)),
                    SizedBox(height: 5),
                    Text(
                        "Web development atau pengembangan web, adalah sebuah proses pembangunan dan pemeliharaan situs web",
                        style: TextStyle(
                            fontSize: 12,
                            height: 1.4,
                            fontWeight: FontWeight.normal)),
                  ],
                ),
              ),
            ],
          ))
        ],
      ),
    );
  }
}
