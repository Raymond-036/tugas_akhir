import 'package:flutter/material.dart';

class Pallete {
  static const Color blueGrey = Color(0xff42526E);
  static const Color grey = Color(0xffA0A2B3);
  static const Color cream = Color(0xfff7f7f7);
  static const Color bgPage = Color(0xffFBFCFE);
  static const Color greenBtn = Colors.red;
  static const Color amber = Color(0xffFFA873);
}
