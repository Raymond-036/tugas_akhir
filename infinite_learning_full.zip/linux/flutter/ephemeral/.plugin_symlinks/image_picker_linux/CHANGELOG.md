## 0.2.1

* Adds `getMedia` method.

## 0.2.0

* Implements initial Linux support.
